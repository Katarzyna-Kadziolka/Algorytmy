﻿using BenchmarkDotNet.Running;
using EfficiencyOfAlgorithms;

BenchmarkRunner.Run<Sorter>();